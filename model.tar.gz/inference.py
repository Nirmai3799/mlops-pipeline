import joblib
import os
import pandas as pd
from xgboost import XGBClassifier

COLUMN_NAMES = [
    "age", "job", "marital", "education", "default", "housing", "loan",
    "contact", "month", "day_of_week", "duration", "campaign", "pdays",
    "previous", "poutcome", "emp_var_rate", "cons_price_idx",
    "cons_conf_idx", "euribor3m", "nr_employed"
]

def model_fn(model_dir):
    model = XGBClassifier()
    model.load_model(os.path.join(model_dir, "xgboost-model"))
    feature_cols = joblib.load(os.path.join(model_dir, "feature_columns.pkl"))
    return model, feature_cols

def input_fn(request_body, request_content_type):
    if request_content_type == "text/csv":
        df = pd.read_csv(pd.io.common.StringIO(request_body), header=None)
        df.columns = COLUMN_NAMES
        return df
    raise ValueError(f"Unsupported content type: {request_content_type}")

def predict_fn(input_data, model_artifacts):
    model, feature_cols = model_artifacts
    input_data = pd.get_dummies(input_data, drop_first=True)
    input_data = input_data.reindex(columns=feature_cols, fill_value=0)
    return model.predict(input_data.values)

def output_fn(prediction, accept):
    return str(prediction.tolist()), accept